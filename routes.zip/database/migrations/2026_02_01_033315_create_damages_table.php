<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('damages', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('sale_item_id')->nullable();
            $table->unsignedBigInteger('purchase_item_id')->nullable();
            $table->text('description')->nullable();
            $table->dateTime('damage_date')->nullable();
            $table->enum('action_taken', ['refund', 'replace', 'repair','not_repaired'])->default('not_repaired');
            $table->enum('type', ['sale', 'purchase'])->default('sale');
            $table->decimal('cost', 10, 2)->default(0);
            $table->integer('damage_quantity')->default(0);
            $table->text('reason')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('outlet_id')->nullable();
            $table->unsignedBigInteger('owner_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('damages');
    }
};
