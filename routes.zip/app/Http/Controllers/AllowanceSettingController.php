<?php

namespace App\Http\Controllers;

use App\Models\AllowanceSetting;
use App\Http\Requests\StoreAlowanceSttingRequest;
use App\Http\Requests\UpdateAlowanceSttingRequest;

class AllowanceSettingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreAlowanceSttingRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(AlowanceStting $alowanceStting)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(AlowanceStting $alowanceStting)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateAlowanceSttingRequest $request, AlowanceStting $alowanceStting)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(AlowanceStting $alowanceStting)
    {
        //
    }
}
