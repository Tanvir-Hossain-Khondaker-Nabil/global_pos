<?php

namespace App\Http\Controllers;

use App\Models\PurchaseReturnItem;
use App\Http\Requests\StorePurchaseReturnItemRequest;
use App\Http\Requests\UpdatePurchaseReturnItemRequest;

class PurchaseReturnItemController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePurchaseReturnItemRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(PurchaseReturnItem $purchaseReturnItem)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PurchaseReturnItem $purchaseReturnItem)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatePurchaseReturnItemRequest $request, PurchaseReturnItem $purchaseReturnItem)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PurchaseReturnItem $purchaseReturnItem)
    {
        //
    }
}
