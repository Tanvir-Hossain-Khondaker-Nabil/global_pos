<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @routes
    @viteReactRefresh
    @vite('resources/js/app.jsx')
    @inertiaHead

    <link rel="stylesheet" href="{{ asset('build/assets/app--nCDZOqT.css') }}">
    <script src="{{ asset('build/assets/app-BDawO320.js') }}"></script>
</head>

<body>
    @inertia
</body>

</html>
