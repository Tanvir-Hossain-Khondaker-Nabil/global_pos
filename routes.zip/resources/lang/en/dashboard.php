<?php

return [
    'title' => 'Dashboard',
    'welcome_message' => 'Hi, Welcome to you!',
    'total_sales' => 'Total Sales',
    'total_payment' => 'Total Payment',
    'total_due' => 'Total Due',
    'total_orders' => 'Total Orders',
    'total_expenses' => 'Total Expenses',
    'currency_tk' => 'Tk',
    'no_permission' => 'You have no permission!',
];