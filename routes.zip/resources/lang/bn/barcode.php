<?php

return [
    'enter_product_code' => 'পণ্য কোড লিখুন',
    'find_product' => 'পণ্য খুঁজুন',
    'size' => 'সাইজ',
    'color' => 'রং',
    'no_colors_available' => 'কোন রং পাওয়া যায়নি',
    'print_sticker' => 'স্টিকার প্রিন্ট করুন',
    'select_size' => '--সাইজ--',
    'select_color' => '--রং--',
];