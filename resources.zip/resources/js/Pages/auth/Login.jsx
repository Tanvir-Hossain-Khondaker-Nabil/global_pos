import React, { useState } from "react";
import GuestLayout from "../../layouts/GuestLayout";
import { Head, useForm, router } from "@inertiajs/react";
import { useTranslation } from "../../hooks/useTranslation";

function Login() {
  const { t, locale } = useTranslation();
  const [isAutoLogin, setIsAutoLogin] = useState(false);

  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: "",
    remember: false,
  });

  const handleLogin = (e) => {
    e.preventDefault();
    setIsAutoLogin(false);

    post(route("login.post"), {
      preserveScroll: true,
      onFinish: () => {
        // optional: reset password field after request
        reset("password");
      },
    });
  };

  // ✅ FIXED: No setData() + setTimeout()
  // Directly post payload so Laravel always receives email/password
  const autoLoginAsUser = (e) => {
    e.preventDefault();
    setIsAutoLogin(true);

    router.post(
      route("login.post"),
      {
        email: "demo@totalbizpos.com",
        password: "demopassword",
        remember: false,
      },
      {
        preserveScroll: true,
        onSuccess: () => {
          console.log("Auto login successful");
        },
        onError: () => {
          console.log("Auto login failed");
        },
        onFinish: () => {
          setIsAutoLogin(false);
        },
      }
    );
  };

  const busy = processing || isAutoLogin;

  return (
    <div className={locale === "bn" ? "bangla-font" : ""}>
      <Head title={t("auth.login", "Login")} />

      <form onSubmit={handleLogin}>
        <fieldset className="fieldset">
          <legend className="fieldset-legend">{t("auth.email", "Email")}*</legend>
          <input
            value={data.email}
            onChange={(e) => setData("email", e.target.value)}
            type="email"
            name="email"
            className="input"
            placeholder={t("auth.enter_email", "Enter email")}
            autoComplete="email"
            required
          />
          {errors.email && <div className="text-red-600 text-sm mt-1">{errors.email}</div>}
        </fieldset>

        <fieldset className="fieldset mt-4">
          <legend className="fieldset-legend">
            {t("auth.password", "Password")}*
          </legend>
          <input
            value={data.password}
            onChange={(e) => setData("password", e.target.value)}
            type="password"
            name="password"
            className="input"
            placeholder={t("auth.enter_password", "Enter password")}
            autoComplete="current-password"
            required
          />
          {errors.password && <div className="text-red-600 text-sm mt-1">{errors.password}</div>}
        </fieldset>

        <label className="label mt-4 flex items-center space-x-2">
          <input
            type="checkbox"
            name="remember"
            onChange={(e) => setData("remember", e.target.checked)}
            checked={data.remember}
            className="checkbox checkbox-sm"
          />
          <span>{t("auth.remember_me", "Remember me")}</span>
        </label>

        <button
          type="submit"
          disabled={busy}
          className="btn bg-[#1e4d2b] text-white w-full mt-6 hover:bg-[#2a5f3b] transition-colors disabled:opacity-50"
        >
          {busy ? t("auth.logging_in", "Logging in...") : t("auth.login_button", "Login")}
        </button>
      </form>

      {/* Auto Login Button - Only for development/testing */}
      <div className="mt-8 pt-6 border-t border-gray-300">
        <div className="text-center mb-4">
          <span className="text-sm text-gray-500 dark:text-gray-400">
            Quick Login (For Testing)
          </span>
        </div>

        <button
          type="button"
          onClick={autoLoginAsUser}
          disabled={busy}
          className="btn bg-blue-500 hover:bg-blue-600 text-white w-full transition-colors disabled:opacity-50"
        >
          {busy ? "Logging in..." : "Login as Demo User"}
        </button>

        <div className="mt-3 p-3 bg-gray-50 border border-gray-200 rounded-md">
          <div className="text-xs text-gray-600 text-center">
            <div className="font-medium mb-1">Demo Credentials:</div>
            <div className="font-mono">demo@totalbizpos.com</div>
            <div className="font-mono">demopassword</div>
          </div>
        </div>
      </div>
    </div>
  );
}

Login.layout = (page) => <GuestLayout>{page}</GuestLayout>;
export default Login;
