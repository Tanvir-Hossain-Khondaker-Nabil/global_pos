import PageHeader from "../../components/PageHeader";
import { Link, router, usePage } from "@inertiajs/react";
import { ArrowLeft, Warehouse, Package, Search, Filter, Shield } from "lucide-react";
import { useState } from "react";

export default function WarehouseProducts({ warehouse, products, isShadowUser }) {
    const [searchTerm, setSearchTerm] = useState("");
    const [filterOutOfStock, setFilterOutOfStock] = useState(false);

    // Helper function to safely format numbers
    const formatNumber = (value) => {
        const num = Number(value) || 0;
        return num.toFixed(2);
    };

    // Helper function to safely get number value
    const getNumber = (value) => {
        return Number(value) || 0;
    };

    // Format currency
    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'BDT'
        }).format(amount || 0);
    };

    // Filter products based on search and stock filter
    const filteredProducts = products.filter(product => {
        const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            product.product_no.toLowerCase().includes(searchTerm.toLowerCase());
        
        const hasStock = filterOutOfStock ? getNumber(product.total_stock) > 0 : true;
        
        return matchesSearch && hasStock;
    });

    // Calculate warehouse statistics
    const totalProducts = products.length;
    const totalItems = products.reduce((sum, product) => sum + getNumber(product.total_stock), 0);
    const totalValue = products.reduce((sum, product) => {
        return sum + product.variants.reduce((variantSum, variant) => {
            return variantSum + getNumber(variant.stock_value);
        }, 0);
    }, 0);

    return (
        <div className="bg-white rounded-box p-5">
            <PageHeader
                title={isShadowUser ? `গুদাম: ${warehouse.name}` : `গুদাম: ${warehouse.name}`}
                subtitle={isShadowUser ? 
                    `${warehouse.name} এর জন্য স্টক ওভারভিউ (${warehouse.code})` : 
                    `${warehouse.name} এর জন্য স্টক ওভারভিউ (${warehouse.code})`
                }
            >
                <div className="flex flex-col sm:flex-row gap-2 items-start sm:items-center">
                    <button
                        onClick={() => router.visit(route("warehouse.list"))}
                        className="btn btn-sm btn-ghost"
                    >
                        <ArrowLeft size={15} /> গুদামে ফিরে যান
                    </button>
                </div>
            </PageHeader>


            {/* Warehouse Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className={`stat rounded-box ${isShadowUser ? 'bg-warning/10' : 'bg-base-200'}`}>
                    <div className="stat-figure text-primary">
                        <Package size={24} />
                    </div>
                    <div className="stat-title">মোট পণ্য</div>
                    <div className="stat-value text-primary">{totalProducts}</div>
                    <div className="stat-desc">বিভিন্ন পণ্য</div>
                </div>

                <div className={`stat rounded-box ${isShadowUser ? 'bg-warning/10' : 'bg-base-200'}`}>
                    <div className="stat-figure text-secondary">
                        <Warehouse size={24} />
                    </div>
                    <div className="stat-title">মোট আইটেম</div>
                    <div className="stat-value text-secondary">{totalItems}</div>
                    <div className="stat-desc">স্টকে ইউনিট</div>
                </div>

                <div className={`stat rounded-box ${isShadowUser ? 'bg-warning/10' : 'bg-base-200'}`}>
                    <div className="stat-figure text-accent">
                        <span className="text-2xl">৳</span>
                    </div>
                    <div className="stat-title">
                        {isShadowUser ? 'স্টক মূল্য' : 'মোট স্টক মূল্য'}
                    </div>
                    <div className="stat-value text-accent">
                        {formatCurrency(totalValue)}
                    </div>
                    <div className="stat-desc">
                        {isShadowUser ? 'মূল্য' : 'বর্তমান স্টক মূল্য'}
                    </div>
                </div>
            </div>

            {/* Filters */}
            <div className="flex flex-col md:flex-row gap-4 mb-6 p-4 bg-base-200 rounded-box">
                <div className="flex-1">
                    <label className="input input-bordered flex items-center gap-2">
                        <Search size={16} />
                        <input
                            type="text"
                            className="grow"
                            placeholder="পণ্য খুঁজুন..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </label>
                </div>
                <div className="flex items-center gap-2">
                    <Filter size={16} />
                    <label className="cursor-pointer label">
                        <input
                            type="checkbox"
                            className="checkbox checkbox-primary"
                            checked={filterOutOfStock}
                            onChange={(e) => setFilterOutOfStock(e.target.checked)}
                        />
                        <span className="label-text ml-2">স্টক নেই এমনগুলি লুকান</span>
                    </label>
                </div>
            </div>

            {/* Products Table */}
            <div className="overflow-x-auto">
                {filteredProducts.length > 0 ? (
                    <div className="space-y-4">
                        {filteredProducts.map((product) => {
                            const productTotalStock = getNumber(product.total_stock);
                            const productTotalValue = product.variants.reduce((sum, variant) => sum + getNumber(variant.stock_value), 0);
                            
                            return (
                                <div key={product.id} className="border border-gray-200 rounded-box">
                                    {/* Product Header */}
                                    <div className="bg-gray-50 p-4 rounded-t-box border-b">
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <h3 className="font-semibold text-lg">{product.name}</h3>
                                                <p className="text-sm text-gray-600">
                                                    কোড: {product.product_no} | 
                                                    ক্যাটাগরি: {product.category?.name || 'N/A'} |
                                                    মোট স্টক: <span className={`font-bold ${productTotalStock === 0 ? 'text-error' : 'text-success'}`}>
                                                        {productTotalStock}
                                                    </span>
                                                </p>
                                                {product.description && (
                                                    <p className="text-sm text-gray-500 mt-1">{product.description}</p>
                                                )}
                                            </div>
                                            <div className="text-right">
                                                <div className={`badge ${isShadowUser ? 'badge-warning' : 'badge-primary'}`}>
                                                    {isShadowUser ? 'পণ্য' : 'পণ্য'}
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Variants Table */}
                                    <div className="p-4">
                                        <table className="table table-auto w-full">
                                            <thead className={isShadowUser ? "bg-warning text-warning-content" : "bg-primary text-primary-content"}>
                                                <tr>
                                                    <th className="bg-opacity-20">ভ্যারিয়েন্ট</th>
                                                    <th className="bg-opacity-20">স্টক</th>
                                                    <th className="bg-opacity-20">
                                                        {isShadowUser ? 'মূল্য' : 'ক্রয় মূল্য'}
                                                    </th>
                                                    <th className="bg-opacity-20">
                                                        {isShadowUser ? 'মূল্য' : 'স্টক মূল্য'}
                                                    </th>
                                                    <th className="bg-opacity-20">স্ট্যাটাস</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {product.variants.map((variant) => {
                                                    const stockQuantity = getNumber(variant.stock_quantity);
                                                    const purchasePrice = getNumber(variant.purchase_price);
                                                    const stockValue = getNumber(variant.stock_value);
                                                    
                                                    return (
                                                        <tr key={variant.id} className="hover:bg-base-100">
                                                            <td>
                                                                <div className="font-medium">
                                                                    {variant.variant_name}
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <span className={`font-bold ${stockQuantity === 0 ? 'text-error' : 'text-success'}`}>
                                                                    {stockQuantity}
                                                                </span>
                                                            </td>
                                                            <td className="font-mono">
                                                                {formatCurrency(purchasePrice)}
                                                            </td>
                                                            <td className="font-mono font-semibold">
                                                                {formatCurrency(stockValue)}
                                                            </td>
                                                            <td>
                                                                <span className={`badge badge-${stockQuantity === 0 ? 'error' : stockQuantity < 10 ? 'warning' : 'success'}`}>
                                                                    {stockQuantity === 0 ? 'স্টক নেই' : 
                                                                     stockQuantity < 10 ? 'কম স্টক' : 'স্টকে আছে'}
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>

                                        {/* Product Summary */}
                                        <div className="mt-4 pt-4 border-t">
                                            <div className="flex justify-between items-center text-sm">
                                                <span className="font-semibold">পণ্য সারাংশ:</span>
                                                <div className="flex gap-4">
                                                    <span>মোট ভ্যারিয়েন্ট: {product.variants.length}</span>
                                                    <span>মোট স্টক: {productTotalStock}</span>
                                                    <span className="font-semibold">
                                                        {isShadowUser ? 'মূল্য: ' : 'মোট মূল্য: '}
                                                        {formatCurrency(productTotalValue)}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded-box">
                        <Package size={48} className="mx-auto text-gray-400 mb-4" />
                        <h3 className="text-lg font-semibold text-gray-500">
                            {isShadowUser ? "কোন শ্যাডো পণ্য পাওয়া যায়নি" : "কোন পণ্য পাওয়া যায়নি"}
                        </h3>
                        <p className="text-gray-400 mt-2">
                            {searchTerm || filterOutOfStock 
                                ? "আপনার অনুসন্ধান বা ফিল্টার মানদণ্ড সামঞ্জস্য করুন" 
                                : isShadowUser ? "এই গুদামে কোন শ্যাডো পণ্য নেই" : "এই গুদামে কোন পণ্য নেই"}
                        </p>
                    </div>
                )}
            </div>
        </div>
    );
}