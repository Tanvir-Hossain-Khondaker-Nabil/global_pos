import { Link, router } from "@inertiajs/react";
import PageHeader from "../../components/PageHeader";
import { 
    ArrowLeft, 
    Eye, 
    Package, 
    User, 
    Building, 
    Calendar,
    DollarSign,
    Percent,
    Hash,
    FileText,
    Trash2
} from "lucide-react";
import { toast } from "react-toastify";

export default function SaleItemShow({ saleItem }) {
    const handleDelete = () => {
        if (confirm('আপনি কি নিশ্চিত যে আপনি এই বিক্রিত আইটেম মুছতে চান? এই কর্মটি পূর্বাবস্থায় ফেরানো যাবে না।')) {
            router.delete(route('sales.items.destroy', { id: saleItem.id }), {
                preserveScroll: true,
                onSuccess: () => {
                    toast.success('বিক্রিত আইটেম সফলভাবে মুছে ফেলা হয়েছে');
                },
                onError: () => {
                    toast.error('বিক্রিত আইটেম মুছতে ব্যর্থ হয়েছে');
                }
            });
        }
    };

    const calculateItemTotal = () => {
        const price = parseFloat(saleItem.unit_price) || 0;
        const quantity = parseFloat(saleItem.quantity) || 0;
        const discount = parseFloat(saleItem.discount) || 0;
        
        const subtotal = price * quantity;
        const discountAmount = (subtotal * discount) / 100;
        return (subtotal - discountAmount).toFixed(2);
    };

    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    return (
        <div className="bg-white rounded-box p-5">
            {/* Header with Actions */}
            <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                    <Link
                        href={route('salesItems.list')}
                        className="btn btn-ghost btn-circle"
                    >
                        <ArrowLeft size={20} />
                    </Link>
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">বিক্রিত আইটেম বিবরণ</h1>
                        <p className="text-gray-600">বিক্রিত আইটেম সম্পর্কে সম্পূর্ণ তথ্য</p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <Link
                        href={route('sales.show', { id: saleItem.sale_id })}
                        className="btn btn-primary btn-sm"
                    >
                        <Eye size={14} />
                        বিক্রয় দেখুন
                    </Link>
                    <button
                        onClick={handleDelete}
                        className="btn btn-error btn-sm"
                    >
                        <Trash2 size={14} />
                        মুছুন
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Main Information */}
                <div className="lg:col-span-2 space-y-6">
                    {/* Product Information Card */}
                    <div className="card bg-base-100 border">
                        <div className="card-body">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="p-2 bg-primary/10 rounded-box">
                                    <Package className="w-6 h-6 text-primary" />
                                </div>
                                <h2 className="card-title">পণ্য তথ্য</h2>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="label font-semibold">পণ্যের নাম</label>
                                    <p className="text-lg">{saleItem.product?.name || 'N/A'}</p>
                                </div>
                                <div>
                                    <label className="label font-semibold">পণ্য কোড</label>
                                    <p className="text-lg">{saleItem.product?.product_no || 'N/A'}</p>
                                </div>
                                <div>
                                    <label className="label font-semibold">ভ্যারিয়েন্ট</label>
                                    <p className="text-lg">{saleItem.variant?.size || 'ভ্যারিয়েন্ট নেই'} ({saleItem.variant?.color || 'রং নেই'})</p>
                                </div>
                                <div>
                                    <label className="label font-semibold">পণ্য নম্বর</label>
                                    <p className="text-lg">{saleItem.product?.product_no || 'N/A'}</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Sale & Pricing Information */}
                    <div className="card bg-base-100 border">
                        <div className="card-body">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="p-2 bg-success/10 rounded-box">
                                    <DollarSign className="w-6 h-6 text-success" />
                                </div>
                                <h2 className="card-title">মূল্য তথ্য</h2>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="label font-semibold">ইউনিট মূল্য</label>
                                    <p className="text-xl font-bold text-success">
                                        {parseFloat(saleItem.unit_price).toFixed(2)} টাকা
                                    </p>
                                </div>
                                <div>
                                    <label className="label font-semibold">পরিমাণ</label>
                                    <p className="text-xl font-bold">
                                        <Hash size={16} className="inline mr-1" />
                                        {saleItem.quantity}
                                    </p>
                                </div>
                                <div>
                                    <label className="label font-semibold">ডিসকাউন্ট</label>
                                    <p className="text-xl font-bold text-warning">
                                        {saleItem.sale.discount}%
                                    </p>
                                </div>
                                <div>
                                    <label className="label font-semibold">ভ্যাট</label>
                                    <p className="text-xl font-bold text-warning">
                                        {saleItem.sale.vat_tax}%
                                    </p>
                                </div>
                                <div>
                                    <label className="label font-semibold">মোট পরিমাণ</label>
                                    <p className="text-2xl font-bold text-primary">
                                        {calculateItemTotal()} টাকা
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Sidebar Information */}
                <div className="space-y-6">
                    {/* Customer Information */}
                    <div className="card bg-base-100 border">
                        <div className="card-body">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="p-2 bg-info/10 rounded-box">
                                    <User className="w-6 h-6 text-info" />
                                </div>
                                <h2 className="card-title">গ্রাহক</h2>
                            </div>
                            
                            <div className="space-y-3">
                                <div>
                                    <label className="label font-semibold">নাম</label>
                                    <p>{saleItem.sale?.customer?.customer_name || 'ওয়াক-ইন গ্রাহক'}</p>
                                </div>
                                {saleItem.sale?.customer?.phone && (
                                    <div>
                                        <label className="label font-semibold">ফোন</label>
                                        <p>{saleItem.sale.customer.phone}</p>
                                    </div>
                                )}
                                {saleItem.sale?.customer?.address && (
                                    <div>
                                        <label className="label font-semibold">ঠিকানা</label>
                                        <p className="text-sm">{saleItem.sale.customer.address}</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Warehouse & Sale Info */}
                    <div className="card bg-base-100 border">
                        <div className="card-body">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="p-2 bg-warning/10 rounded-box">
                                    <Building className="w-6 h-6 text-warning" />
                                </div>
                                <h2 className="card-title">অবস্থান ও বিক্রয়</h2>
                            </div>
                            
                            <div className="space-y-3">
                                <div>
                                    <label className="label font-semibold">গুদাম</label>
                                    <p>{saleItem.warehouse?.name || 'N/A'}</p>
                                </div>
                                <div>
                                    <label className="label font-semibold">বিক্রয় ইনভয়েস</label>
                                    <p className="font-mono">{saleItem.sale?.invoice_no || 'N/A'}</p>
                                </div>
                                <div>
                                    <label className="label font-semibold">বিক্রয় করেছেন</label>
                                    <p>{saleItem.sale?.user?.name || 'সিস্টেম অ্যাডমিন'}</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Timestamp Information */}
                    <div className="card bg-base-100 border">
                        <div className="card-body">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="p-2 bg-gray-100 rounded-box">
                                    <Calendar className="w-6 h-6 text-gray-600" />
                                </div>
                                <h2 className="card-title">টাইমস্ট্যাম্প</h2>
                            </div>
                            
                            <div className="space-y-3">
                                <div>
                                    <label className="label font-semibold">বিক্রয় তারিখ</label>
                                    <p>{formatDate(saleItem.created_at)}</p>
                                </div>
                                <div>
                                    <label className="label font-semibold">সর্বশেষ আপডেট</label>
                                    <p>{formatDate(saleItem.updated_at)}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Calculation Breakdown */}
            <div className="mt-6 card bg-base-100 border">
                <div className="card-body">
                    <h3 className="card-title mb-4">গণনা ব্রেকডাউন</h3>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
                        <div className="p-4 bg-base-200 rounded-box">
                            <div className="text-sm text-gray-600">ইউনিট মূল্য</div>
                            <div className="text-lg font-bold">{parseFloat(saleItem.unit_price).toFixed(2)} টাকা</div>
                        </div>
                        <div className="p-4 bg-base-200 rounded-box">
                            <div className="text-sm text-gray-600">পরিমাণ</div>
                            <div className="text-lg font-bold">{saleItem.quantity}</div>
                        </div>
                        <div className="p-4 bg-base-200 rounded-box">
                            <div className="text-sm text-gray-600">সাবটোটাল</div>
                            <div className="text-lg font-bold">
                                {(saleItem.unit_price * saleItem.quantity).toFixed(2)} টাকা
                            </div>
                        </div>
                        <div className="p-4 bg-primary/10 rounded-box">
                            <div className="text-sm text-gray-600">চূড়ান্ত মোট</div>
                            <div className="text-lg font-bold text-primary">
                                {calculateItemTotal()} টাকা
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}