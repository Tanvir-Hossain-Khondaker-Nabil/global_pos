<?php

return [
    'title' => 'Extra cash list',
    'subtitle' => 'Manage your all extra cash from here.',
    'add_new' => 'Add new',
    'created_by' => 'Created by',
    'amount' => 'Amount',
    'date' => 'Date',
    'name' => 'Name',
    'email' => 'Email',
    'data_not_found' => 'Data not found!',
    'add_extra_cash' => 'Add extra cash',
    'add_now' => 'Add now',
    'confirm_delete' => 'Are you sure you want to delete this?',
];