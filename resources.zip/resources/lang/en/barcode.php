<?php

return [
    'enter_product_code' => 'Enter product code',
    'find_product' => 'Find Product',
    'size' => 'Size',
    'color' => 'Color',
    'no_colors_available' => 'No colors available',
    'print_sticker' => 'Print Sticker',
    'select_size' => '--Size--',
    'select_color' => '--Color--',
];