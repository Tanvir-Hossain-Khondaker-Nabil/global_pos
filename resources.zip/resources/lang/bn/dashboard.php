<?php

return [
    'title' => 'ড্যাশবোর্ড',
    'welcome_message' => 'হাই, আপনাকে স্বাগতম!',
    'total_sales' => 'মোট বিক্রয়',
    'total_payment' => 'মোট পেমেন্ট',
    'total_due' => 'মোট বাকি',
    'total_orders' => 'মোট অর্ডার',
    'total_expenses' => 'মোট ব্যয়',
    'currency_tk' => 'টাকা',
    'no_permission' => 'আপনার অনুমতি নেই!',
];